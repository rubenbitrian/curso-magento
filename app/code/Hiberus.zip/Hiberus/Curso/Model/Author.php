<?php

namespace Hiberus\Curso\Model;

class Author
{
    public function getAuthorName() {
        return 'Almodobar';
    }
}
