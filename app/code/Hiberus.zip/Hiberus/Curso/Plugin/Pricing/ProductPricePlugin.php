<?php

namespace Hiberus\Curso\Plugin\Pricing;

class ProductPricePlugin
{
    /**
     * @param \Magento\Framework\Pricing\Render\Amount $subject
     * @param $result
     * @return string
     */
    public function afterFormatCurrency(
        \Magento\Framework\Pricing\Render\Amount $subject,
        $result
    ) : string
    {
        $result = strval($result) . " por unidad";
        return $result;
    }
}
